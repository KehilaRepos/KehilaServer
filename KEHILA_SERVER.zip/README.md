# Kehila
A centralized hub for charitable activities
