import express from 'express';
import cors from 'cors';
import { signUp, verify_email, login, resend_email_verification } from '../controllers/authenticationController.js';

const loginRouter = express.Router();

loginRouter.use(cors());

loginRouter.route('/').get((req, res) => {
  res.status(200).json({ message: 'Welcome to the Kehila API' });
});

loginRouter.route('/signup').post(signUp);

loginRouter.route('/verifyEmail').post(verify_email);

loginRouter.route('/login').post(login);

loginRouter.route('/resendEmailVerification').post(resend_email_verification);

//loginRouter.route('/verify-token').get(verifyToken);
// done? think so :D
export default loginRouter;
